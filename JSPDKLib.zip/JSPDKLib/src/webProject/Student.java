package webProject;

public class Student {
	private String student_id;
	private String student_pw;
	private String student_used;
	
	public String getStudent_used() {
		return student_used;
	}
	public void setStudent_used(String student_used) {
		this.student_used = student_used;
	}
	public String getStudent_id() {
		return student_id;
	}
	public void setStudent_id(String student_id) {
		this.student_id = student_id;
	}
	public String getStudent_pw() {
		return student_pw;
	}
	public void setStudent_pw(String student_pw) {
		this.student_pw = student_pw;
	}
}
