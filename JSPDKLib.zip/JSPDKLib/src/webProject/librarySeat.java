package webProject;

public class librarySeat {
	private int seat_num;
	private String seat_used;
	private String seat_used_id;
	private String seat_option;
	
	public int getSeat_num() {
		return seat_num;
	}
	public void setSeat_num(int seat_num) {
		this.seat_num = seat_num;
	}
	
	public String getSeat_used() {
		return seat_used;
	}
	public void setSeat_used(String seat_used) {
		this.seat_used = seat_used;
	}
	public String getSeat_used_id() {
		return seat_used_id;
	}
	public void setSeat_used_id(String seat_used_id) {
		this.seat_used_id = seat_used_id;
	}
	public String getSeat_option() {
		return seat_option;
	}
	public void setSeat_option(String seat_option) {
		this.seat_option = seat_option;
	}
	
	
	
	
	
	
}
